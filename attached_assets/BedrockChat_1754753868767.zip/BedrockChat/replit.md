# AI Knowledge Assistant

## Overview

This is a Streamlit-based AI Knowledge Assistant application that provides an interactive chat interface powered by AWS Bedrock. The application enables users to query AI models and knowledge bases through a modern web interface with customizable theming options. It serves as a front-end for AWS Bedrock's AI capabilities, offering both direct model interactions and knowledge base queries.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit web framework for rapid UI development
- **Layout**: Wide layout with expandable sidebar for controls and settings
- **Theming**: Custom CSS system with dark/light mode toggle functionality
- **State Management**: Streamlit's session state for maintaining conversation history and user preferences
- **Responsive Design**: CSS-based styling with message containers and animations

### Backend Architecture
- **Cloud Provider**: AWS Bedrock for AI model access and knowledge base operations
- **Client Architecture**: Custom BedrockClient class wrapping AWS SDK operations
- **Service Integration**: 
  - bedrock-runtime for direct model inference
  - bedrock-agent-runtime for knowledge base queries
  - bedrock-agent for knowledge base discovery and management
- **Error Handling**: Comprehensive exception handling for AWS service interactions
- **Caching**: Streamlit's resource caching for client initialization to optimize performance

### Authentication & Security
- **AWS Credentials**: Environment variable-based configuration with hardcoded fallbacks
- **Session Management**: Streamlit's built-in session handling
- **Regional Configuration**: Configurable AWS region (defaults to us-east-1)

### Data Flow
- **Message Storage**: In-memory session state for conversation history
- **Request Processing**: Synchronous processing through AWS Bedrock APIs
- **Response Handling**: Real-time message display with timestamp formatting
- **Knowledge Base Discovery**: Automatic detection and selection of available knowledge bases

## External Dependencies

### Cloud Services
- **AWS Bedrock Runtime**: Core AI model inference service
- **AWS Bedrock Agent Runtime**: Knowledge base query execution
- **AWS Bedrock Agent**: Knowledge base management and discovery

### Python Libraries
- **streamlit**: Web application framework and UI components
- **boto3**: AWS SDK for Python service integration
- **botocore**: Low-level AWS service error handling

### Development Tools
- **Environment Variables**: AWS credential and configuration management
- **JSON**: Data serialization for AWS API interactions
- **datetime**: Timestamp generation for message formatting
- **os**: Environment variable access and system integration