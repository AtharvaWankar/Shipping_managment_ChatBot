def get_custom_css(dark_mode=False):
    """Generate custom CSS based on theme preference"""
    
    if dark_mode:
        # Professional Dark Theme - Elegant browns and golds
        bg_color = "#1A1612"
        secondary_bg = "#2D2821"
        text_color = "#F5E6D3"
        user_msg_bg = "#8B4513"
        bot_msg_bg = "#3E3325"
        border_color = "#5D4E37"
        accent_color = "#D2691E"
        input_bg = "#2D2821"
        button_bg = "#8B4513"
        button_hover_bg = "#A0522D"
        sidebar_bg = "#252016"
    else:
        # Professional Light Theme - Warm creams and browns
        bg_color = "#FDF8F0"
        secondary_bg = "#FFFEF7"
        text_color = "#3E2723"
        user_msg_bg = "#8B4513"
        bot_msg_bg = "#F5F5DC"
        border_color = "#D7CCC8"
        accent_color = "#8B4513"
        input_bg = "#FFFEF7"
        button_bg = "#8B4513"
        button_hover_bg = "#A0522D"
        sidebar_bg = "#F9F4E8"
    
    return f"""
    <style>
    /* Import Professional Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;700;900&family=Exo+2:wght@300;400;500;600;700&display=swap');
    
    /* Professional Global Theme */
    .stApp {{
        background-color: {bg_color};
        color: {text_color};
        font-family: 'Exo 2', 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
    }}
    
    /* Stationary Sidebar - Fixed Width 1/8 of Screen */
    .css-1d391kg, .stSidebar {{
        background: {sidebar_bg};
        border-right: 3px solid {border_color};
        box-shadow: 4px 0 15px rgba(139, 69, 19, 0.15);
        width: 12.5vw !important;
        max-width: 12.5vw !important;
        min-width: 12.5vw !important;
        position: fixed !important;
        left: 0 !important;
        top: 0 !important;
        height: 100vh !important;
        z-index: 999;
        transform: none !important;
        margin-left: 0 !important;
        transition: none !important;
    }}
    
    .stSidebar > div {{
        background: linear-gradient(180deg, {sidebar_bg}, rgba(139, 69, 19, 0.03));
        border-right: 1px solid {border_color};
        padding: 10px 8px;
        width: 100% !important;
        height: 100vh;
        overflow-y: auto;
        overflow-x: hidden;
    }}
    
    /* Adjust main content area to account for fixed sidebar */
    .main .block-container {{
        margin-left: 12.5vw !important;
        max-width: calc(87.5vw - 2rem) !important;
        padding-left: 2rem;
    }}
    
    /* Hide sidebar toggle button since sidebar is now stationary */
    section[data-testid="stSidebar"] button[kind="header"] {{
        display: none !important;
    }}
    
    /* Make sure sidebar toggle button is always accessible */
    .css-1lcbmhc, .css-1cypcdb, .css-17ziqus {{
        background-color: {accent_color} !important;
        color: white !important;
        border: none !important;
        border-radius: 4px !important;
        padding: 4px 8px !important;
    }}
    
    /* Sidebar toggle arrow styling */
    .css-17ziqus:hover, .css-1lcbmhc:hover {{
        background-color: {button_hover_bg} !important;
    }}
    
    /* Custom sidebar toggle button styling */
    div[data-testid="stButton"] button[key="sidebar_toggle"] {{
        background: linear-gradient(45deg, {accent_color}, #26A69A);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 8px 12px;
        font-size: 16px;
        font-weight: bold;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }}
    
    div[data-testid="stButton"] button[key="sidebar_toggle"]:hover {{
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        background: linear-gradient(45deg, {button_hover_bg}, #1DB584);
    }}
    
    /* Professional Message containers */
    .user-message {{
        background: linear-gradient(135deg, {user_msg_bg}, #A0522D);
        color: white;
        padding: 16px 20px;
        border-radius: 20px 20px 5px 20px;
        margin: 12px 0;
        margin-left: 25%;
        box-shadow: 
            0 4px 15px rgba(139, 69, 19, 0.25),
            inset 0 1px 0 rgba(255,255,255,0.1);
        animation: slideInRight 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        font-weight: 500;
        border: 1px solid rgba(255,255,255,0.1);
    }}
    
    .bot-message {{
        background: linear-gradient(135deg, {bot_msg_bg}, rgba(139, 69, 19, 0.08));
        color: {text_color};
        padding: 16px 20px;
        border-radius: 20px 20px 20px 5px;
        margin: 12px 0;
        margin-right: 25%;
        border: 2px solid {border_color};
        box-shadow: 
            0 4px 15px rgba(139, 69, 19, 0.15),
            inset 0 1px 0 rgba(139, 69, 19, 0.05);
        animation: slideInLeft 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        font-weight: 400;
    }}
    
    .message-content {{
        font-size: 15px;
        font-family: 'Exo 2', sans-serif;
        font-weight: 400;
        line-height: 1.6;
        margin-bottom: 6px;
        white-space: pre-wrap;
        word-wrap: break-word;
        letter-spacing: 0.3px;
    }}
    
    .message-timestamp {{
        font-size: 11px;
        opacity: 0.7;
        text-align: right;
        margin-top: 4px;
    }}
    
    /* Animation keyframes */
    @keyframes slideInRight {{
        from {{
            opacity: 0;
            transform: translateX(20px);
        }}
        to {{
            opacity: 1;
            transform: translateX(0);
        }}
    }}
    
    @keyframes slideInLeft {{
        from {{
            opacity: 0;
            transform: translateX(-20px);
        }}
        to {{
            opacity: 1;
            transform: translateX(0);
        }}
    }}
    
    /* Input styling - mirror glass finish */
    .stTextInput > div > div > input {{
        border-radius: 25px;
        border: 1px solid rgba(255,255,255,0.2);
        padding: 14px 20px;
        font-size: 14px;
        background: linear-gradient(145deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        color: {text_color};
        transition: all 0.3s ease;
        box-shadow: 
            0 8px 32px 0 rgba(31, 38, 135, 0.37),
            inset 0 1px 0 rgba(255,255,255,0.1),
            inset 0 -1px 0 rgba(255,255,255,0.1);
        border-image: linear-gradient(45deg, rgba(255,255,255,0.3), rgba(255,255,255,0.1)) 1;
    }}
    
    .stTextInput > div > div > input:focus {{
        border: 1px solid rgba(46, 134, 171, 0.5);
        box-shadow: 
            0 8px 32px 0 rgba(46, 134, 171, 0.3),
            0 0 0 3px rgba(46, 134, 171, 0.1),
            inset 0 1px 0 rgba(255,255,255,0.2),
            inset 0 -1px 0 rgba(255,255,255,0.2);
        background: linear-gradient(145deg, rgba(46, 134, 171, 0.1), rgba(46, 134, 171, 0.05));
        transform: translateY(-2px);
    }}
    
    .stTextInput > div > div > input::placeholder {{
        color: rgba({text_color}, 0.6);
        font-style: italic;
    }}
    
    /* Professional Button styling */
    .stButton > button {{
        border-radius: 10px;
        border: none;
        background: linear-gradient(135deg, {button_bg}, {button_hover_bg});
        color: white;
        font-family: 'Exo 2', sans-serif;
        font-weight: 600;
        padding: 8px 16px;
        font-size: 13px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 4px 12px rgba(139, 69, 19, 0.25);
        min-height: 36px;
        letter-spacing: 0.5px;
        text-transform: uppercase;
    }}
    
    .stButton > button:hover {{
        background-color: {button_hover_bg};
        transform: translateY(-1px);
        box-shadow: 0 3px 6px rgba(0,0,0,0.15);
    }}
    
    /* Metrics styling */
    .metric-container {{
        background-color: {secondary_bg};
        padding: 10px;
        border-radius: 8px;
        border: 1px solid {border_color};
        margin: 5px 0;
    }}
    
    /* Form styling */
    .stForm {{
        background-color: transparent;
        border: none;
    }}
    
    /* Spinner styling */
    .stSpinner > div {{
        border-top-color: {accent_color} !important;
    }}
    
    /* Download button styling */
    .stDownloadButton > button {{
        background-color: {button_bg};
        color: white;
        border: none;
        border-radius: 8px;
        width: 100%;
        font-size: 12px;
        padding: 6px 12px;
        min-height: 32px;
        transition: all 0.3s ease;
    }}
    
    .stDownloadButton > button:hover {{
        background-color: {button_hover_bg};
        transform: translateY(-1px);
        box-shadow: 0 3px 6px rgba(0,0,0,0.15);
    }}
    
    /* Custom scrollbar */
    ::-webkit-scrollbar {{
        width: 8px;
    }}
    
    ::-webkit-scrollbar-track {{
        background: {bg_color};
    }}
    
    ::-webkit-scrollbar-thumb {{
        background: {accent_color};
        border-radius: 4px;
    }}
    
    ::-webkit-scrollbar-thumb:hover {{
        background: #1976D2;
    }}
    
    /* Error and success messages */
    .stAlert {{
        border-radius: 8px;
        border-left: 4px solid {accent_color};
    }}
    
    /* Hide Streamlit branding */
    #MainMenu {{visibility: hidden;}}
    footer {{visibility: hidden;}}
    header {{visibility: hidden;}}
    
    /* Cool gradient for title */
    h1 {{
        background: linear-gradient(45deg, {accent_color}, #26A69A, #9C27B0);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-weight: bold;
    }}
    
    /* Responsive design */
    @media (max-width: 768px) {{
        .user-message, .bot-message {{
            margin-left: 5%;
            margin-right: 5%;
        }}
        
        .message-content {{
            font-size: 13px;
        }}
    }}
    </style>
    """
