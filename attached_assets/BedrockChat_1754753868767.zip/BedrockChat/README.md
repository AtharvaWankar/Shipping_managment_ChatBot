# AI Knowledge Assistant - Streamlit Chat Bot

A beautiful Streamlit-based AI chat assistant that integrates with AWS Bedrock knowledge base, featuring dark/light themes and a modern glassmorphism design.

## Features

- 🤖 **AI-Powered Chat**: Integrates with AWS Bedrock Claude models
- 🎨 **Beautiful UI**: Glassmorphism input design with mirror glass finish
- 🌓 **Theme Toggle**: Switch between dark and light modes
- 📱 **Responsive Design**: Works on desktop and mobile devices
- 💾 **Chat History**: Save and export conversation history
- ⚡ **Real-time Updates**: Messages appear instantly
- 📊 **Session Statistics**: Track message counts and activity

## Getting Started

### Prerequisites

- Python 3.11+
- AWS Bedrock access with Claude model permissions
- AWS credentials (Access Key ID and Secret Access Key)

### Installation

The required packages are already installed:
- `streamlit`
- `boto3` 
- `botocore`

### Configuration

1. **AWS Credentials**: Set your AWS credentials as environment variables:
   ```bash
   export AWS_ACCESS_KEY_ID=your_access_key
   export AWS_SECRET_ACCESS_KEY=your_secret_key
   ```

2. **AWS Region**: The app defaults to `us-east-1` but can be configured via:
   ```bash
   export AWS_DEFAULT_REGION=your-preferred-region
   ```

## Running the Application

### Start the App
```bash
streamlit run app.py --server.port 5000
```

### Stop the App
```bash
# Method 1: Kill all Streamlit processes
pkill -f streamlit

# Method 2: Find and kill specific process
ps aux | grep streamlit
kill [process_id]

# Method 3: Use Ctrl+C in the terminal where it's running
```

### Restart the App
```bash
# Kill existing processes
pkill -f streamlit

# Start fresh
streamlit run app.py --server.port 5000
```

## Usage

1. **Open the app** in your browser at `http://localhost:5000`

2. **Toggle sidebar** using the ☰ button in the top-left corner

3. **Switch themes** using the 🌓 Theme button in the sidebar

4. **Chat with AI** by typing your questions in the glass input bar

5. **Manage chat history** using the sidebar options:
   - Clear chat history
   - Export chat as JSON
   - View session statistics

## Troubleshooting

### Common Issues

**"Port 5000 already in use"**
```bash
pkill -f streamlit
# Then restart the app
```

**"Access denied" or "Model not found"**
- Check your AWS credentials
- Ensure you have enabled Claude models in AWS Bedrock console
- Verify your AWS region settings

**"Inference profile required"**
- For newer Claude models, create an inference profile in AWS Bedrock console
- Navigate to: Bedrock → Provisioned Throughput → Inference Profiles

### AWS Bedrock Setup

1. Go to [AWS Bedrock Console](https://console.aws.amazon.com/bedrock/)
2. Navigate to "Model Access" in the sidebar
3. Enable Claude models (recommended: Claude 3.7 Sonnet)
4. Create a knowledge base if needed
5. Set up inference profiles for newer models

## File Structure

```
├── app.py              # Main Streamlit application
├── bedrock_client.py   # AWS Bedrock integration
├── styles.py           # CSS styling and themes
├── .streamlit/
│   └── config.toml     # Streamlit configuration
└── README.md           # This file
```

## Customization

### Themes
Edit `styles.py` to customize colors and styling:
- Dark/light theme colors
- Glassmorphism effects
- Button and input styling
- Message bubble appearance

### AWS Models
Modify `bedrock_client.py` to use different Claude models or adjust the model selection priority.

## Development

### Adding Features
1. Modify `app.py` for UI changes
2. Update `bedrock_client.py` for AI functionality
3. Adjust `styles.py` for visual improvements
4. Update this README for new features

### Debugging
- Use the "Test AWS Connection" button to verify Bedrock access
- Check the "Show All Models (Debug)" option to see available models
- Monitor the terminal for error messages

## Support

For issues related to:
- **AWS Bedrock**: Check AWS documentation and IAM permissions
- **Streamlit**: Refer to Streamlit documentation
- **Application bugs**: Review error messages in the terminal

---

**Enjoy your AI chat assistant!** 🚀