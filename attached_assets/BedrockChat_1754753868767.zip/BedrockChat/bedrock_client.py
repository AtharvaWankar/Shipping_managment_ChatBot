import boto3
import json
import streamlit as st
from botocore.exceptions import ClientError, NoCredentialsError

class BedrockClient:
    """AWS Bedrock client for knowledge base interactions"""
    
    def __init__(self, access_key, secret_key, region):
        """Initialize the Bedrock client with AWS credentials"""
        self.access_key = access_key
        self.secret_key = secret_key
        self.region = region
        
        try:
            # Initialize Bedrock Runtime client
            self.bedrock_runtime = boto3.client(
                'bedrock-runtime',
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                region_name=region
            )
            
            # Initialize Bedrock Agent Runtime client for knowledge base
            self.bedrock_agent_runtime = boto3.client(
                'bedrock-agent-runtime',
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                region_name=region
            )
            
            self.knowledge_base_id = self._get_knowledge_base_id()
            
        except Exception as e:
            st.error(f"Failed to initialize Bedrock client: {str(e)}")
            raise e
    
    def _get_knowledge_base_id(self):
        """Get the first available knowledge base ID"""
        try:
            # Try to list knowledge bases to get the ID
            bedrock_agent = boto3.client(
                'bedrock-agent',
                aws_access_key_id=self.access_key,
                aws_secret_access_key=self.secret_key,
                region_name=self.region
            )
            
            response = bedrock_agent.list_knowledge_bases()
            knowledge_bases = response.get('knowledgeBaseSummaries', [])
            
            if knowledge_bases:
                kb_id = knowledge_bases[0]['knowledgeBaseId']
                st.success(f"✅ Connected to Knowledge Base: {kb_id}")
                return kb_id
            else:
                st.warning("⚠️ No knowledge bases found in your account")
                return None
                
        except Exception as e:
            st.warning(f"⚠️ Could not list knowledge bases: {str(e)}")
            # Return a default knowledge base ID that user should configure
            return None
    
    def query_knowledge_base(self, query, max_results=5):
        """Query the knowledge base with a user question"""
        if not self.knowledge_base_id:
            return "I'm sorry, but I couldn't connect to a knowledge base. Please ensure you have a knowledge base set up in AWS Bedrock."
        
        try:
            # First try to get available models
            available_models = self._get_available_models()
            
            # Use Claude 3.7 Sonnet with inference profile approach
            model_options = [
                'anthropic.claude-3-7-sonnet-20250219-v1:0'    # Your available Claude 3.7 Sonnet
            ]
            
            last_error = None
            response = None
            # Try to find and use an inference profile first
            inference_profiles = self._get_inference_profiles()
            
            for model_id in model_options:
                # Try with inference profile first
                if inference_profiles:
                    for profile in inference_profiles:
                        if 'claude-3-7-sonnet' in profile.lower():
                            try:
                                response = self.bedrock_agent_runtime.retrieve_and_generate(
                                    input={
                                        'text': query
                                    },
                                    retrieveAndGenerateConfiguration={
                                        'type': 'KNOWLEDGE_BASE',
                                        'knowledgeBaseConfiguration': {
                                            'knowledgeBaseId': self.knowledge_base_id,
                                            'modelArn': profile
                                        }
                                    }
                                )
                                break  # Success with inference profile
                            except ClientError as e:
                                continue  # Try next profile
                    else:
                        # If no profile worked, try direct model ID
                        try:
                            response = self.bedrock_agent_runtime.retrieve_and_generate(
                                input={
                                    'text': query
                                },
                                retrieveAndGenerateConfiguration={
                                    'type': 'KNOWLEDGE_BASE',
                                    'knowledgeBaseConfiguration': {
                                        'knowledgeBaseId': self.knowledge_base_id,
                                        'modelArn': model_id
                                    }
                                }
                            )
                        except ClientError as e:
                            last_error = e
                            continue
                else:
                    # No profiles available, try direct model ID
                    try:
                        response = self.bedrock_agent_runtime.retrieve_and_generate(
                            input={
                                'text': query
                            },
                            retrieveAndGenerateConfiguration={
                                'type': 'KNOWLEDGE_BASE',
                                'knowledgeBaseConfiguration': {
                                    'knowledgeBaseId': self.knowledge_base_id,
                                    'modelArn': model_id
                                }
                            }
                        )
                        break  # Success
                    except ClientError as e:
                        last_error = e
                        continue
            else:
                # If all models failed, raise the last error
                if last_error:
                    raise last_error
            
            # Extract the generated response
            if response and 'output' in response and 'text' in response['output']:
                generated_text = response['output']['text']
                
                # Format the response nicely
                formatted_response = self._format_response(generated_text)
                return formatted_response
            else:
                return "I couldn't find a relevant answer in the knowledge base."
                
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            
            if error_code == 'ValidationException':
                return f"There was an issue with the request format: {error_message}"
            elif error_code == 'ResourceNotFoundException':
                return "The specified knowledge base was not found. Please check your configuration."
            elif error_code == 'AccessDeniedException':
                return "Access denied. Please check your AWS permissions for Bedrock services."
            else:
                return f"An error occurred while querying the knowledge base: {error_message}"
                
        except NoCredentialsError:
            return "AWS credentials not found. Please check your access keys."
            
        except Exception as e:
            return f"An unexpected error occurred: {str(e)}"
    
    def _format_response(self, text):
        """Format the response text for better readability"""
        # Clean up the text
        formatted_text = text.strip()
        
        # Add proper line breaks for better readability
        paragraphs = formatted_text.split('\n\n')
        formatted_paragraphs = []
        
        for paragraph in paragraphs:
            # Clean up each paragraph
            clean_paragraph = paragraph.strip()
            if clean_paragraph:
                formatted_paragraphs.append(clean_paragraph)
        
        # Join paragraphs with proper spacing
        return '\n\n'.join(formatted_paragraphs)
    
    def _get_available_models(self):
        """Get list of available foundation models"""
        try:
            # Use bedrock client instead of bedrock-runtime
            bedrock_client = boto3.client(
                'bedrock',
                aws_access_key_id=self.access_key,
                aws_secret_access_key=self.secret_key,
                region_name=self.region
            )
            response = bedrock_client.list_foundation_models()
            return [model['modelId'] for model in response.get('modelSummaries', [])]
        except Exception as e:
            st.warning(f"Could not list available models: {str(e)}")
            return []
    
    def _get_inference_profiles(self):
        """Get list of available inference profiles"""
        try:
            bedrock_client = boto3.client(
                'bedrock',
                aws_access_key_id=self.access_key,
                aws_secret_access_key=self.secret_key,
                region_name=self.region
            )
            # Try to list inference profiles
            response = bedrock_client.list_inference_profiles()
            profiles = []
            for profile in response.get('inferenceProfileSummaries', []):
                profiles.append(profile.get('inferenceProfileArn', ''))
            return profiles
        except Exception as e:
            st.info(f"No inference profiles found: {str(e)}")
            return []

    def test_connection(self):
        """Test the connection to AWS Bedrock and show detailed model information"""
        try:
            # Use bedrock client to list foundation models
            bedrock_client = boto3.client(
                'bedrock',
                aws_access_key_id=self.access_key,
                aws_secret_access_key=self.secret_key,
                region_name=self.region
            )
            response = bedrock_client.list_foundation_models()
            models = response.get('modelSummaries', [])
            available_models = [model['modelId'] for model in models]
            
            # Show available Claude models specifically
            claude_models = [model for model in available_models if 'claude' in model.lower()]
            
            st.success(f"✅ Connected to AWS Bedrock. Available models: {len(available_models)}")
            
            # Force show Claude models
            if claude_models:
                st.write("**Available Claude models:**")
                for model in claude_models:
                    st.write(f"• {model}")
            else:
                st.write("**No Claude models found. Showing first 10 models:**")
                for model in sorted(available_models)[:10]:
                    st.write(f"• {model}")
                
                st.write("**Looking for anthropic models:**")
                anthropic_models = [model for model in available_models if 'anthropic' in model.lower()]
                for model in anthropic_models:
                    st.write(f"• {model}")
            
            return True, f"Successfully connected to AWS Bedrock with {len(available_models)} models available"
        except Exception as e:
            return False, f"Connection failed: {str(e)}"
